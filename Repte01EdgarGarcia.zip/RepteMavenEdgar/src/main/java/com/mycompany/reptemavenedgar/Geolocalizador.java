/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.reptemavenedgar;

import com.drew.imaging.ImageProcessingException;
import com.drew.lang.GeoLocation;
import com.google.code.geocoder.Geocoder;
import com.google.code.geocoder.GeocoderRequestBuilder;
import com.google.code.geocoder.model.GeocodeResponse;
import com.google.code.geocoder.model.GeocoderRequest;
import com.google.code.geocoder.model.GeocoderResult;
import com.google.code.geocoder.model.LatLng;
import java.io.IOException;

/**
 *
 * @author Edgar
 */
public class Geolocalizador {

    private final Geocoder geocoder = new Geocoder();
    private Imagen imagen;

    public Geolocalizador(Imagen imagen) {
        this.imagen = imagen;
    }

    public String sacarCiudadPorCoordenadas() throws ImageProcessingException, IOException {
        GeoLocation coordenadas = imagen.getCoordenadas();

        double lat, lon;

        lat = coordenadas.getLatitude();
        lon = coordenadas.getLongitude();

        LatLng p = new LatLng(Double.toString(lon), Double.toString(lat));
        GeocoderRequest geocoderRequest = new GeocoderRequestBuilder().setLocation(p).setLanguage("es").getGeocoderRequest();
        System.out.println(geocoderRequest.toString());
        GeocodeResponse geocoderResponse;

        try {
            geocoderResponse = geocoder.geocode(geocoderRequest);
            System.out.println(geocoderResponse.toString());
            GeocoderResult result = geocoderResponse.getResults().get(0);

            return result.toString();
        } catch (Exception e) {
        }
        
        return null;
    }

}
