/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.reptemavenedgar;

import com.drew.imaging.ImageMetadataReader;
import com.drew.imaging.ImageProcessingException;
import com.drew.lang.GeoLocation;
import com.drew.metadata.Metadata;
import com.drew.metadata.exif.GpsDirectory;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

/**
 *
 * @author Edgar
 */
public class Imagen {
    
    private final File imagen;
    private final GeoLocation coordenadas;
    private String nombre;

    public Imagen(File imagen) throws ImageProcessingException, IOException {
        this.imagen = imagen;
        this.nombre = imagen.getName();
        Metadata metadata = ImageMetadataReader.readMetadata(imagen);
        GpsDirectory geoDir = metadata.getFirstDirectoryOfType(GpsDirectory.class);
        this.coordenadas= geoDir.getGeoLocation();
    }
    
    public void mostrarCoordenadas() throws ImageProcessingException, IOException{
        JOptionPane.showMessageDialog(null,"Nombre: "+nombre+",     Coordenadas: "+coordenadas);
    }
    
    public GeoLocation getCoordenadas() throws ImageProcessingException, IOException{
        return coordenadas;
    }
    
    public BufferedImage redimensionar( double porcentaje ){
        
        BufferedImage bf = null;
        try {
            bf = ImageIO.read(new File(imagen.getAbsolutePath()));
        } catch (IOException ex) {
            Logger.getLogger(Imagen.class.getName()).log(Level.SEVERE, null, ex);
        }
        int ancho = bf.getWidth();
        int alto = bf.getHeight();
        int escalaAncho = (int)(porcentaje* ancho);
        int escalaAlto = (int)(porcentaje*alto);
        BufferedImage bufim = new BufferedImage(escalaAncho, escalaAlto, bf.getType());
        Graphics2D g = bufim.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(bf, 0,0, escalaAncho,escalaAlto, 0,0,ancho,alto, null);
        g.dispose();
        return bufim;
}
    
    public String getNombre(){
        return nombre;
    }
    
}
