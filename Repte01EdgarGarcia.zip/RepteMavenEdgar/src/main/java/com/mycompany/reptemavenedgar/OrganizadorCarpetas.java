/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.reptemavenedgar;

import com.drew.imaging.ImageMetadataReader;
import com.drew.imaging.ImageProcessingException;
import com.drew.metadata.Metadata;
import com.drew.metadata.exif.ExifSubIFDDirectory;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

/**
 *
 * @author Edgar
 */
public class OrganizadorCarpetas {
    
    private File origen;
    private File destino;

    public OrganizadorCarpetas(File origen, File destino) {
        this.origen = origen;
        this.destino = destino;
    }
    
    public File[] arrayImagenes(){
        File[] imagenes = origen.listFiles();
        return imagenes;
    }
    
    public void organizar() throws ImageProcessingException, IOException{
        
        String fechaImagen;
        if (!destino.exists()) {
            destino.mkdir();
        }
        File[] imagenes = arrayImagenes();
        ArrayList<String> fechas = new ArrayList<>();
        
        //Añadir al arrayList nombres de las carpetas

        for (int i = 0; i < imagenes.length; i++) {
            Metadata metadata = ImageMetadataReader.readMetadata(imagenes[i]);
            ExifSubIFDDirectory imagen = metadata.getFirstDirectoryOfType(ExifSubIFDDirectory.class);

            Date fecha = imagen.getDate(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL);
            fechaImagen = Integer.toString(fecha.getYear() + 1900) + Integer.toString(fecha.getMonth());
            fechas.add(fechaImagen);

        }

        // Eliminar repetidos arraylist creando un set que no admite repetidos y despues los devuelvo al arraylist 
        Set<String> hs = new HashSet<>();
        hs.addAll(fechas);

        fechas.clear();
        fechas.addAll(hs);
        
        //Creación de las carpetas distribuidas por fechas en la carpeta de destino
        for (int i = 0; i < fechas.size(); i++) {
            File carpetaFecha = new File(destino + "\\" + fechas.get(i));
            carpetaFecha.mkdir();
        }
        
        //Meter imagenes de la carpeta origen en su correspondiente carpeta segun la fecha en la carpeta de destino elegida
        for (int i = 0; i < imagenes.length; i++) {

            Metadata metadata = ImageMetadataReader.readMetadata(imagenes[i]);
            ExifSubIFDDirectory imagen = metadata.getFirstDirectoryOfType(ExifSubIFDDirectory.class);

            Date fecha = imagen.getDate(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL);
            fechaImagen = Integer.toString(fecha.getYear() + 1900) + Integer.toString(fecha.getMonth());

            for (int j = 0; j < fechas.size(); j++) {
                if (fechaImagen.equals(fechas.get(j))) {
                    Imagen img = new Imagen(imagenes[i]);
                    
                    ImageIO.write(img.redimensionar(0.1),"jpg",new File(destino.getName() + "\\" + fechaImagen + "\\" + img.getNombre()));
                }
            }

        }
        JOptionPane.showMessageDialog(null,"Carpetas creadas coorectamente y fotos reducidas");
    }
    
    
    
}
