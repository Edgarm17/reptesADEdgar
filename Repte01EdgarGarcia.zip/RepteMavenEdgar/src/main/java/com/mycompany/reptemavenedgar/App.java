/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.reptemavenedgar;

import com.drew.imaging.ImageProcessingException;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JOptionPane;
/**
 *
 * @author Edgar
 */
public class App {
    
    static Scanner s = new Scanner(System.in);
    
    public static void main(String[] args) throws ImageProcessingException, IOException {
        
// OPCIÓN 1/4 (ORGANIZACIÓN EN CARPETAS Y RESIZE)

        String origen;
        String destino;

        origen = JOptionPane.showInputDialog(null, "Introduce la carpeta de origen:");
        destino = JOptionPane.showInputDialog(null, "Ahora la carpeta de destino: ");
        
        File carpetaOrigen = new File(origen);
        File carpetaDestino = new File(destino);
        
        OrganizadorCarpetas organizadorCarpetas = new OrganizadorCarpetas(carpetaOrigen,carpetaDestino);
        organizadorCarpetas.organizar();
        
        
        
//OPCIÓN 2 (MOSTRAR NOMBRE Y COORDENADAS)

        File[] imagenes = organizadorCarpetas.arrayImagenes();

        for (int i = 0; i < imagenes.length; i++) {
            
            Imagen img = new Imagen(imagenes[i]);
            img.mostrarCoordenadas();
            
        }
        
        
//OPCIÓN 3 CIUDADES A PARTIR DE COORDENADAS (No funciona por no tener clave de la API de Google Maps y no se como crearla ni implementarlo) El acceso al request lo denega

//        for (int i = 0; i < imagenes.length; i++) {
//            Imagen img = new Imagen(imagenes[i]);
//            Geolocalizador geo = new Geolocalizador(img);
//            System.out.println("La ciudad de la imagen es: "+geo.sacarCiudadPorCoordenadas());
//        }

    }

}
